package com.ssafy.happyhouse.model.service;

import java.util.Map;

public interface CrimePopulService {

	Map<String, String> getCrimePopul(String gugun_code);
	
}
